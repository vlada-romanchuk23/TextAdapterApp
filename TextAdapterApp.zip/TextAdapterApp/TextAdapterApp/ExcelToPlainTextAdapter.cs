﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextAdapterApp
{
    public class ExcelToPlainTextAdapter : IText
    {
        private ExcelText excelText;

        public ExcelToPlainTextAdapter(ExcelText excelText)
        {
            this.excelText = excelText;
        }

        public string GetText()
        {
            // Перетворює дані з Excel-формату у простий текст
            string excelContent = excelText.GetExcelContent();
            return excelContent.Replace(",", " "); // заміна ком на пробіли
        }
    }

}

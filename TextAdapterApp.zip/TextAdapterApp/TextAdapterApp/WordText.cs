﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextAdapterApp
{
    public class WordText : IText
    {
        private string content;

        public WordText(string content)
        {
            this.content = content;
        }

        // Реалізуємо метод GetText для інтерфейсу IText
        public string GetText()
        {
            return GetWordContent(); // Повертає специфічний для Word формат
        }

        public string GetWordContent()
        {
            // Симуляція специфічного формату для Word, наприклад додавання заголовка
            return "Word Document: " + content;
        }
    }
}

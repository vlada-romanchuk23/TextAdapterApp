﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextAdapterApp
{
    public class PlainText : IText
    {
        private string content;

        public PlainText(string content)
        {
            this.content = content;
        }

        public string GetText()
        {
            return content; // Просто повертає текст без форматування
        }
    }

}

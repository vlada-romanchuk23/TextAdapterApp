﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextAdapterApp
{
    public class WordToPlainTextAdapter : IText
    {
        private WordText wordText;

        public WordToPlainTextAdapter(WordText wordText)
        {
            this.wordText = wordText;
        }

        public string GetText()
        {
            string wordContent = wordText.GetWordContent();
            return wordContent.Replace("Word Document: ", ""); // Видаляємо специфічний формат
        }
    }

}

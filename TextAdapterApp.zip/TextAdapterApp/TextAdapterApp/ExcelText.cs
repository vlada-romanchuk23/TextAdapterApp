﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextAdapterApp
{
    public class ExcelText : IText
    {
        private string content;

        public ExcelText(string content)
        {
            this.content = content;
        }

        // Доданий метод для реалізації інтерфейсу IText
        public string GetText()
        {
            return GetExcelContent(); // Повертає специфічний для Excel формат
        }

        public string GetExcelContent()
        {
            // Симуляція специфічного формату для Excel, наприклад розділення комами
            return "Excel Data: " + content.Replace(" ", ",");
        }
    }

}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TextAdapterApp
{
    public partial class Form1 : Form
    {
        private TextProcessor textProcessor;

        public Form1()
        {
            InitializeComponent();
            textProcessor = new TextProcessor();
        }

        // Обробник натискання кнопки для обробки тексту
        private void btnProcess_Click(object sender, EventArgs e)
        {
            IText text = null;

            // Вибір адаптера в залежності від формату
            if (cmbFormat.SelectedItem.ToString() == "Word")
            {
                text = new WordText(txtInput.Text); // Створюємо об'єкт WordText з введеним текстом
                text = new WordToPlainTextAdapter((WordText)text); // Використовуємо адаптер для перетворення в PlainText
            }
            else if (cmbFormat.SelectedItem.ToString() == "Excel")
            {
                text = new ExcelText(txtInput.Text); // Створюємо об'єкт ExcelText з введеним текстом
                text = new ExcelToPlainTextAdapter((ExcelText)text); // Використовуємо адаптер для перетворення в PlainText
            }
            else
            {
                text = new PlainText(txtInput.Text); // Якщо обраний PlainText, просто використовуємо введений текст
            }

            // Встановлення обробленого тексту у текстове поле
            txtInput.Text = text.GetText(); // Виводимо результат роботи адаптера у TextBox
        }

  
        private void Form1_Load(object sender, EventArgs e)
        {

        }

    }
}
